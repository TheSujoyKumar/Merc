package aero.sita.psp.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.constants.ProjectConstants;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Util extends TestBase {

	private static final Logger LOG = LogManager.getLogger(Util.class);

	public static void copyFile(File origin, File destination) throws IOException {
		FileUtils.copyFile(origin, destination);
	}

	public static void replaceFileText(String filePath, String oldText, String newText) {
		try {
			Path path = Paths.get(filePath);
			Charset charset = StandardCharsets.UTF_8;

			String content = new String(Files.readAllBytes(path), charset);
			content = content.replaceAll(oldText, newText);
			Files.write(path, content.getBytes(charset));
		} catch (IOException ioe) {
		}

	}

	public void updatePropertiesFile(String fileName, String tagName, String tagValue) throws ConfigurationException {
		File propertiesFile = new File(fileName);
		PropertiesConfiguration config = new PropertiesConfiguration(propertiesFile);
		config.setProperty(tagName, tagValue);
		config.save();
	}

	public static String getEncryptedData(String EncryptionFilePath, String SearchData) {
		File file = new File(EncryptionFilePath);
		String EncryptionData = "";
		String ch = "";
		String searchString = "<!--Start of Encrypted Data for " + '\u0022' + SearchData + '\u0022' + " -->";
		try {
			Scanner scanner = new Scanner(file);
			int lineNum = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				lineNum++;
				if (line.contains(searchString)) {
					EncryptionData = scanner.nextLine();
					break;
				}
			}
		} catch (FileNotFoundException e) {
			// handle this
		}
		return EncryptionData;
	}

	public static void launch3DSecureHelperPage(String secureHelperFormPath) throws IOException, InterruptedException {
		reportLog(Status.INFO, LOG, "Launching 3D Secure Helper Page");
		String destFilePath = ReportManager.outputResponsePath + "\\3DSecureForm.html";

		copyFile(new File(secureHelperFormPath), new File(destFilePath));

		replaceFileText(destFilePath, "@@action@@", testData.get("action"));
		replaceFileText(destFilePath, "@@value@@", testData.get("value"));

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(destFilePath);
		reportLog(Status.INFO, LOG, "3D Secure Helper Page launched");
		reportLogAttachScreenshot(captureScreenShot(driver, ReportManager.outputResponsePath));
		driver.findElement(By.xpath("//input[@name='Identify yourself']")).click();
		reportLog(Status.INFO, LOG, "Clicked on Submit Button (Browser Loading Page)");
		reportLogAttachScreenshot(captureScreenShot(driver, ReportManager.outputResponsePath));
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		reportLog(Status.INFO, LOG, "Clicked on Submit Button (3D Secure Simulator Page)");
		
		Thread.sleep(2000);
		String PaRes = driver.findElement(By.xpath("//table[1]//tbody/tr[2]/td[2]")).getText();
		reportLogAttachScreenshot(captureScreenShot(driver, ReportManager.outputResponsePath));
		reportLog(Status.INFO, LOG, "PaRes Value captured : "+PaRes);
		testData.put("PaRes", PaRes);
		driver.quit();
		reportLog(Status.INFO, LOG, "3D Secure Helper Page Closed");

	}

	public static String captureScreenShot(WebDriver driver, String screenshotFolder) {
		String screenShotPath = null;
		try {
			File outputFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			screenShotPath = screenshotFolder + "\\" + new SimpleDateFormat("dd_MM_yyyy_HHmmss").format(new Date())
					+ ".png";
			Thread.sleep(300);
			FileUtils.copyFile(outputFile, new File(screenShotPath));
		} catch (final Exception e) {
		}
		return screenShotPath;
	}
}