package aero.sita.psp.testcases;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.constants.ProjectConstants;
import aero.sita.psp.serviceutil.AuthorizePaymentUtil;
import aero.sita.psp.utility.ExcelReader;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.Util;

public class AuthorizePaymentTest extends TestBase{
	
	private static final Logger LOG = LogManager.getLogger(AuthorizePaymentTest.class);
	
	HttpResponse response;
	static String xmlRequestPath="";
	Document requestDoc;
	static String responseXmlString  ="";
	
	
	
	@AfterMethod
	public void flushReport() {
		try{
			extent.flush();
		}catch(Exception e){
			
		}
	}
	
	@DataProvider(name = "TestData")
    public Object[] dataProviderGetData(Method method) {
           return ExcelReader.getMapDataFromSpreadSheet(ProjectConstants.testDataPath + "TestData.xlsx",method.getName());
    }
	/**
	 * Method to test AuthorizePayment Service (Non-3D).
	 * @param testData
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 * @throws ParserConfigurationException 
	 * @throws SAXException 
	 */
	@Test(priority=1,dataProvider = "TestData")
	public void authorizePaymentTest(Map<String, String> data) throws ClientProtocolException, IOException, TransformerException, SAXException, ParserConfigurationException {
		
		testData = data;
		if(testData.get("ExecutionFlag").equalsIgnoreCase("N")) {
			return;
		}
		
		try {
		
		initExtentReport(testData.get("TestCaseName"), testData.get("TestCaseDescription"));
		
		response = AuthorizePaymentUtil.executeAuthorizePayment();
		
		responseXmlString = SoapUtil.verifyResponse(response, "AuthorizePayment");
		
		SoapUtil.verifyExpectedResult(responseXmlString);
		
		}
		catch(Exception e) {
			LOG.info(e);
		}
		
	}
	
	/**
	 * Method to test AuthorizePayment Service (Non-3D).
	 * @param testData
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 * @throws ParserConfigurationException 
	 * @throws SAXException 
	 */
	@Test(priority=2,dataProvider = "TestData")
	public void authorizePayment3DTest(Map<String, String> data) throws ClientProtocolException, IOException, TransformerException, SAXException, ParserConfigurationException {
		
		testData = data;
		if(testData.get("ExecutionFlag").equalsIgnoreCase("N")) {
			return;
		}
		
		try {
		
		initExtentReport(testData.get("TestCaseName"), testData.get("TestCaseDescription"));
		
		response = AuthorizePaymentUtil.executeAuthorizePayment();
		
		responseXmlString = SoapUtil.verifyResponse(response, "AuthorizePayment");
		
		AuthorizePaymentUtil.captureAuthorizePaymentResponseData(responseXmlString);
		
		Util.launch3DSecureHelperPage(ProjectConstants.WORLDPAY_HTML_FORM);
		
		response = AuthorizePaymentUtil.executeAuthorizePayment3D();
		
		responseXmlString = SoapUtil.verifyResponse(response, "AuthorizePayment 3D");
		
		SoapUtil.verifyExpectedResult(responseXmlString);
		
		}
		catch(Exception e) {
			LOG.info(e);
		}
		
	}
	
	
}
