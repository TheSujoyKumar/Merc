package aero.sita.psp.serviceutil;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.utility.ReportManager;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.XmlUtil;

public class AuthorizePaymentUtil extends TestBase {

	private static final Logger LOG = LogManager.getLogger(AuthorizePaymentUtil.class);
	static Document requestDoc;
	static String xmlRequestPath = "";
	static HttpResponse response;

	/**
	 * Method to update AuthorizePayment WorldPay Request XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createAuthorizePaymentWorldPayRequest()
			throws TransformerException {
		reportLog(Status.INFO, LOG, "Updating AuthorizePayment request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("AuthorizePaymentWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "common:Email", testData.get("EmailID"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PurchaseDescription", testData.get("PurchaseDescription"));
		SoapUtil.setNodeValue(requestDoc, "common:CardHolderName", testData.get("CardHolderName"));
		

		String paymentReference = RandomStringUtils.randomAlphanumeric(10).toUpperCase();

		if (testData.get("PaymentReference").equalsIgnoreCase("Random")) {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", paymentReference);
		} else {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));
		}
		SoapUtil.setNodeValue(requestDoc, "psp_common:AccountInfo", "MerchantID", testData.get("MerchantID"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:AccountInfo", "Password", testData.get("Password"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardType", testData.get("CardType"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardNumber", testData.get("CardNumber"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "SeriesCode", testData.get("SeriesCode"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "ExpireDate", testData.get("ExpireDate"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "Amount", testData.get("Amount"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "CurrencyCode", testData.get("CurrencyCode"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "DecimalPlaces", testData.get("DecimalPlaces"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("AuthorizePaymentWorldPay"));
		
		
	}
	/**
	 * Method to update AuthorizePayment WorldPay 3D Request XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createAuthorizePaymentWorldPay3DRequest()
			throws TransformerException {
		reportLog(Status.INFO, LOG, "Updating AuthorizePayment 3D request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("AuthorizePayment3DWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "common:CardHolderEmail", testData.get("EmailID"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PurchaseDescription", testData.get("PurchaseDescription"));
		SoapUtil.setNodeValue(requestDoc, "common:CardHolderName", testData.get("CardHolderName"));
		
		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));
		SoapUtil.setNodeValue(requestDoc, "IATA_AuthorizePaymentRQ", "EchoToken", testData.get("EchoToken"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaRes", testData.get("PaRes"));
		
		
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardType", testData.get("CardType_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardNumber", testData.get("CardNumber_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "SeriesCode", testData.get("SeriesCode_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "ExpireDate", testData.get("ExpireDate_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "Amount", testData.get("Amount_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "CurrencyCode", testData.get("CurrencyCode_3D"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "DecimalPlaces", testData.get("DecimalPlaces_3D"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("AuthorizePayment3DWorldPay"));
		
		
	}
	/**
	 * Method to update AuthorizePayment WireCard Request XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createAuthorizePaymentWireCardRequest()
			throws TransformerException {
		reportLog(Status.INFO, LOG, "Updating AuthorizePayment request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("AuthorizePaymentWireCard"));

		
		SoapUtil.setNodeValue(requestDoc, "common:Email", testData.get("EmailID"));
		SoapUtil.setNodeValue(requestDoc, "common:CardHolderFirstName", testData.get("CardHolderName"));
		
		
		String requestReference = RandomStringUtils.randomAlphanumeric(10).toUpperCase();
		
		if (testData.get("RequestReference").equalsIgnoreCase("Random")) {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", requestReference);
		} else {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("RequestReference"));
			}
		

		if (testData.get("PaymentReference").equalsIgnoreCase("Random")) {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "RequestReference", requestReference);
			
		} else {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "RequestReference", testData.get("RequestReference"));
			}
		reportLog(Status.INFO, LOG, "PaymentReference updated");
		SoapUtil.setNodeValue(requestDoc, "psp_common:AccountInfo", "MerchantID", testData.get("MerchantID"));
		
		SoapUtil.setNodeValue(requestDoc, "psp_common:UserAccountInfo", "Username", testData.get("Username"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:UserAccountInfo", "Password", testData.get("Password"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardType", testData.get("CardType"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "CardNumber", testData.get("CardNumber"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "SeriesCode", testData.get("SeriesCode"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentCard", "ExpireDate", testData.get("ExpireDate"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "Amount", testData.get("Amount"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "CurrencyCode", testData.get("CurrencyCode"));
		
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("AuthorizePaymentWireCard"));
		
	}

	/**
	 * execute AuthorizePayment Request (Non 3D).
	 * 
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeAuthorizePayment()
			throws ClientProtocolException, IOException, TransformerException {

		reportLog(Status.INFO, LOG, "AuthorizePayment Service EndPoint : " + endPoints.get("AuthorizePayment"));
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			xmlRequestPath = createAuthorizePaymentWorldPayRequest();
			reportLog(Status.INFO, LOG, "Executing AuthorizePayment Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("AuthorizePayment"),
					xmlFiles.get("AuthorizePaymentWorldPay"), xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			xmlRequestPath = createAuthorizePaymentWireCardRequest();
			reportLog(Status.INFO, LOG, "Executing AuthorizePayment Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("AuthorizePayment"),
					xmlFiles.get("AuthorizePaymentWireCard"), xmlRequestPath);
		}
		return response;
	}
	
	/**
	 * execute AuthorizePayment Request (3D).
	 * 
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeAuthorizePayment3D()
			throws ClientProtocolException, IOException, TransformerException {

		reportLog(Status.INFO, LOG, "AuthorizePayment 3D Service EndPoint : " + endPoints.get("AuthorizePayment"));
		
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			xmlRequestPath = createAuthorizePaymentWorldPay3DRequest();
			reportLog(Status.INFO, LOG, "Executing AuthorizePayment 3D Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("AuthorizePayment"),
					xmlFiles.get("AuthorizePayment3DWorldPay"), xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			//xmlRequestPath = createAuthorizePaymentWireCardRequest();
			reportLog(Status.INFO, LOG, "Executing AuthorizePayment 3D Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("AuthorizePayment"),
					xmlFiles.get("AuthorizePaymentWireCard"), xmlRequestPath);
		}
		return response;
	}

	/**
	 * Method to capture Data from Authorize Payment Response.
	 * 
	 * @param responseXmlString
	 * @throws DOMException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */

	public static void captureAuthorizePaymentResponseData(String responseXmlString)
			throws DOMException, SAXException, IOException, ParserConfigurationException {
		String requestReference = "";
		String decimalPlaces = "";
		String merchantID = "";
		String transactionReference = "";

		reportLog(Status.INFO, LOG, "Capturing AuthorizePayment Response data");
		
		String paymentReference = SoapUtil.getNodeValue(responseXmlString, "MerchantInfo", "PaymentReference");
		String currencyCode =  SoapUtil.getNodeValue(responseXmlString, "psp_common:PaymentAmount", "CurrencyCode");
		String amount_AP =  SoapUtil.getNodeValue(responseXmlString, "psp_common:PaymentAmount", "Amount");	
		
		
		String action =  SoapUtil.getNodeValue(responseXmlString, "psp_common:Form", "action");
		String value =  SoapUtil.getNodeValue(responseXmlString, "psp_common:Input", "value");
		String EchoToken = SoapUtil.getNodeValue(responseXmlString, "IATA_AuthorizePaymentRS", "EchoToken");
		
		
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			
			decimalPlaces =  SoapUtil.getNodeValue(responseXmlString, "psp_common:PaymentAmount", "DecimalPlaces");
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			transactionReference = SoapUtil.getNodeValue(responseXmlString, "IATA_AuthorizePaymentRS", "TransactionReference");
			requestReference = SoapUtil.getNodeValue(responseXmlString, "MerchantInfo", "RequestReference");
			merchantID =  SoapUtil.getNodeValue(responseXmlString, "psp_common:AccountInfo", "MerchantID");	
		}
		
		testData.put("PaymentReference", paymentReference);
		testData.put("RequestReference", requestReference);
		testData.put("TransactionReference", transactionReference);
		testData.put("CurrencyCode", currencyCode);
		testData.put("Amount_AP", amount_AP);
		testData.put("DecimalPlaces", decimalPlaces);
		testData.put("MerchantID", merchantID);
		testData.put("action", action);
		testData.put("value", value);
		testData.put("EchoToken", EchoToken);
	}
}
