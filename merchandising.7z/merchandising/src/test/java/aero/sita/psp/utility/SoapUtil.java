package aero.sita.psp.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.SkipException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.constants.ProjectConstants;

public class SoapUtil extends TestBase{
	private static final Logger LOG = LogManager.getLogger(SoapUtil.class);
	
	/**
	 * Method to execute SOAP request.
	 * @param endPoint
	 * @param xmlFileName
	 * @param xmlRequestPath
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static HttpResponse executeSoapRequest(String endPoint, String xmlFileName, String xmlRequestPath) throws ClientProtocolException, IOException {
		String date = "";
		File requestFile = null;
		File destination = null;
		
		if(xmlRequestPath.isEmpty()) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			date = sdf.format(timestamp);
			requestFile = new File(ProjectConstants.REQUEST_XML_FILES_PATH+xmlFileName+".xml");
			destination = new File(ReportManager.outputResponsePath + "\\" + xmlFileName+ "_" + date + ".xml");
			Util.copyFile(requestFile, destination);
		}else{
			destination = new File(xmlRequestPath);
		}
		
		HttpPost post = new HttpPost(endPoint);
		post.setEntity(new InputStreamEntity(new FileInputStream(destination)));
		post.setHeader("Content-type","text/xml");
		HttpClient cilent = HttpClientBuilder.create().build();
		return cilent.execute(post);
	}
	
	/**
	 * Method to validate Xml response.
	 * @param response
	 * @param serviceName
	 * @return
	 * @throws IOException
	 */
	public static String verifyResponse(HttpResponse response,String serviceName) throws IOException {
		String responseXmlString  = XmlUtil.httpResponseToString(response);
		if(response.getStatusLine().getStatusCode() == 200) {
			reportLog(Status.PASS, LOG, serviceName+" request executed successfully");
			reportLog(Status.INFO, LOG,serviceName+" Response status code "+response.getStatusLine().getStatusCode());
		}
		else {
			reportLog(Status.FAIL, LOG, serviceName+" request not executed successfully");
			reportLog(Status.INFO, LOG,serviceName+" Response status code "+response.getStatusLine().getStatusCode());
			XmlUtil.convertXmlStringToFile(responseXmlString, serviceName);
			throw new SkipException(serviceName+"Request exection failed. Hence Skipping the test");
		}
		reportLogAsCodeBlock(Status.INFO,LOG, serviceName+" Response", responseXmlString);
		XmlUtil.convertXmlStringToFile(responseXmlString, serviceName);
		return responseXmlString;
	}
	
	/**
	 * Method to verify an element is present in response or not.
	 * @param responseXmlString
	 */
	public static void verifyExpectedResult(String responseXmlString) {
		if(responseXmlString.contains(testData.get("ExpectedTextinResponse"))) {
			reportLog(Status.INFO,LOG, testData.get("ExpectedTextinResponse")+" found in Respone");
			reportLog(Status.PASS,LOG, "Respone validated successfully");
			
		}else {
			reportLog(Status.INFO,LOG, testData.get("ExpectedTextinResponse")+" not found in Respone");
			reportLog(Status.FAIL,LOG, "Respone not validated successfully");
		}
	}
	/**
	 * Method to set Node Value.
	 * @param requestDoc
	 * @param tagName
	 * @param valueToSet
	 */
	public static void setNodeValue(Document requestDoc,String tagName,String valueToSet) {
		requestDoc.getElementsByTagName(tagName).item(0).getFirstChild().setNodeValue(valueToSet);
		reportLog(Status.INFO, LOG, tagName+" value updated to "+valueToSet);
	}
	/**
	 * Method to set Node Value (Attribute Value).
	 * @param requestDoc
	 * @param tagName
	 * @param attributeName
	 * @param valueToSet
	 */
	public static void setNodeValue(Document requestDoc,String tagName,String attributeName, String valueToSet) {
		requestDoc.getElementsByTagName(tagName).item(0).getAttributes().getNamedItem(attributeName).setNodeValue(valueToSet);
		reportLog(Status.INFO, LOG, attributeName+" value updated to "+valueToSet);
	}
	
	/**
	 * Method to get Node Value.
	 * @param responseXmlString
	 * @param tagName
	 * @return nodeValue
	 * @throws DOMException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */
	public static String getNodeValue(String responseXmlString,String tagName) throws DOMException, SAXException, IOException, ParserConfigurationException {
		String nodeValue = "";
		try {
		 nodeValue = XmlUtil.parseXmlString(responseXmlString).getElementsByTagName(tagName).item(0).getTextContent();
		reportLog(Status.INFO, LOG, tagName+" value captured="+nodeValue);
		}catch(Exception e) {
			return nodeValue;
		}
		return nodeValue;
	}
	/**
	 * Method to get Node Value (Attribute Value).
	 * @param responseXmlString
	 * @param tagName
	 * @param attributeName
	 * @return nodeValue (Attribute Value).
	 * @throws DOMException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */
	public static String getNodeValue(String responseXmlString,String tagName,String attributeName) throws DOMException, SAXException, IOException, ParserConfigurationException {
		String nodeValue = "";
		try {
		nodeValue = XmlUtil.parseXmlString(responseXmlString).getElementsByTagName(tagName).item(0).getAttributes().getNamedItem(attributeName).getNodeValue();	
		reportLog(Status.INFO, LOG, attributeName+" value captured="+nodeValue);
		
		}catch(Exception e) {
			return nodeValue;
		}
		return nodeValue;
	}
}
