package aero.sita.psp.serviceutil;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.utility.ReportManager;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.XmlUtil;

public class VoidPaymentUtil extends TestBase {
	
	private static final Logger LOG = LogManager.getLogger(VoidPaymentUtil.class);
	static Document requestDoc;
	static String xmlRequestPath = "";
	static HttpResponse response;
	
	/**
	 * Method to update Void Payment WorldPay Request XML.
	 * 
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createVoidPaymentWorldPayRequest()
			throws TransformerException {
		
		reportLog(Status.INFO, LOG, "Updating Void Payment request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("VoidPaymentWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "TransactionID", testData.get("PaymentReference"));

		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("VoidPaymentWorldPay"));
		
		
	}
	/**
	 * execute Void Payment Request.
	 * 
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeVoidPayment()
			throws ClientProtocolException, IOException, TransformerException {

		reportLog(Status.INFO, LOG, "Void Payment Service EndPoint : " + endPoints.get("VoidPayment"));
		
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			xmlRequestPath = createVoidPaymentWorldPayRequest();
			reportLog(Status.INFO, LOG, "Executing Void Payment Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("VoidPayment"),
					xmlFiles.get("VoidPaymentWorldPay"), xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			//xmlRequestPath = createAuthorizePaymentWireCardRequest();
			reportLog(Status.INFO, LOG, "Executing Transaction Status check Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("VoidPayment"),
					xmlFiles.get("VoidPaymentWorldPay"), xmlRequestPath);
		}
		return response;
	}

}
