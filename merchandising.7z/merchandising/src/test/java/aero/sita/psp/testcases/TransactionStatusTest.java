package aero.sita.psp.testcases;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.constants.ProjectConstants;
import aero.sita.psp.serviceutil.AuthorizePaymentUtil;
import aero.sita.psp.serviceutil.TransactionStatusUtil;
import aero.sita.psp.utility.ExcelReader;
import aero.sita.psp.utility.SoapUtil;

public class TransactionStatusTest extends TestBase{
	
	private static final Logger LOG = LogManager.getLogger(TransactionStatusTest.class);
	
	HttpResponse response;
	static String xmlRequestPath="";
	Document requestDoc;
	static String responseXmlString  ="";
	
	
	
	@AfterMethod
	public void flushReport() {
		try{
			extent.flush();
		}catch(Exception e){
			
		}
	}
	
	@DataProvider(name = "TestData")
    public Object[] dataProviderGetData(Method method) {
           return ExcelReader.getMapDataFromSpreadSheet(ProjectConstants.testDataPath + "TestData.xlsx",method.getName());
    }
	/**
	 * Method to test Transaction Status Check Service.
	 * @param testData
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 * @throws ParserConfigurationException 
	 * @throws SAXException 
	 */
	@Test(priority=1,dataProvider = "TestData")
	public void transactionStatusTest(Map<String, String> data) throws ClientProtocolException, IOException, TransformerException, SAXException, ParserConfigurationException {
		
		testData = data;
		
		if(testData.get("ExecutionFlag").equalsIgnoreCase("N")) {
			return;
		}
		
		try {
		
		initExtentReport(testData.get("TestCaseName"), testData.get("TestCaseDescription"));
		
		response = AuthorizePaymentUtil.executeAuthorizePayment();
		
		responseXmlString = SoapUtil.verifyResponse(response, "AuthorizePayment");
		
		AuthorizePaymentUtil.captureAuthorizePaymentResponseData(responseXmlString);
		
		response = TransactionStatusUtil.executeTransactionStatusCheck();
		
		responseXmlString = SoapUtil.verifyResponse(response, "Transaction Status Check");
		
		SoapUtil.verifyExpectedResult(responseXmlString);
		
		}
		catch(Exception e) {
			LOG.info(e);
		}
		
	}
	
	
	
	
}
