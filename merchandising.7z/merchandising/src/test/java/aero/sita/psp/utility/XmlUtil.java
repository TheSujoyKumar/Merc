package aero.sita.psp.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.http.HttpResponse;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import aero.sita.psp.constants.ProjectConstants;

public class XmlUtil {

	public static Document parseXmlFile(String xmlFileName) {
		String filePath = ProjectConstants.REQUEST_XML_FILES_PATH + xmlFileName + ".xml";
		File xmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return doc;
	}

	public static Document parseHtmlFile(String htmlFileName) {
		String filePath = ProjectConstants.REQUEST_XML_FILES_PATH + htmlFileName + ".html";
		File xmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return doc;
	}

	public static Document parseXmlString(String xmlString)
			throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(xmlString));
		Document doc = builder.parse(src);

		return doc;
	}

	public static String updateXml(Document doc, String xmlFileName) throws TransformerException {
		// String filePath = ProjectConstants.requestXmlFilesPath+xmlFileName + ".xml";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String date = sdf.format(timestamp);

		String filePath = xmlFileName + "_Request_" + date + ".xml";
		doc.getDocumentElement().normalize();
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filePath));
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
		return filePath;
	}

	public static String httpResponseToString(HttpResponse response) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		String line = "";
		StringBuffer sb = new StringBuffer();
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}
		return sb.toString();
	}

	public static void convertXmlStringToFile(String xmlString, String resonseName) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String date = sdf.format(timestamp);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			String fileName = ReportManager.outputResponsePath + "\\" + resonseName + "_Response_" + date + ".xml";
			// String fileName = System.getProperty("user.dir")+ "\\reports\\" + resonseName
			// + ".xml";
			builder = factory.newDocumentBuilder();
			// Use String reader
			Document document = builder.parse(new InputSource(new StringReader(xmlString)));
			TransformerFactory tranFactory = TransformerFactory.newInstance();
			Transformer aTransformer = tranFactory.newTransformer();
			Source src = new DOMSource(document);
			Result dest = new StreamResult(new File(fileName));
			aTransformer.transform(src, dest);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
