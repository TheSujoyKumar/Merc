package aero.sita.psp.utility;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class ReportManager {
	public static String outputResponsePath = "";
	public static ExtentReports getReportInstance(String testName) {
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String date = sdf.format(timestamp);
		//new File(System.getProperty("user.dir")+"\\reports\\"+testName).mkdir();
		new File(System.getProperty("user.dir")+"\\reports\\"+testName+"_"+date+"\\").mkdir();
		outputResponsePath = System.getProperty("user.dir")+"\\reports\\"+testName+"_"+date;
		
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(outputResponsePath+"\\Report_"+testName+"_"+date+".html");
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		return extent;
	}

}
