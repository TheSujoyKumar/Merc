package aero.sita.psp.constants;

public interface ProjectConstants {

	/** \\src\\test\\resources\\requestXmlFiles\\ */
	String REQUEST_XML_FILES_PATH = System.getProperty("user.dir")+"\\src\\test\\resources\\requestXmlFiles\\";
	/** \\src\\test\\resources\\testData\\EndPointURLs.xlsx */
	String ENDPOINTS_URLS_FILE_PATH = System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\EndPointURLs.xlsx";
	/** \\src\\test\\resources\\testData\\RequestXmlFiles.xlsx */
	
	String requestXmlFilePath = System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\RequestXmlFiles.xlsx";
	String testDataPath = System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\";
	String envPropertiesFile = System.getProperty("user.dir")+"\\src\\test\\resources\\environment.properties";
	String encrypyUtilityPath = System.getProperty("user.dir")+"\\src\\test\\resources\\EncryptUtility\\RunEncryption.bat";
	String fopDetailsPath = System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\FOPData.xlsx";
	
	/** \\src\\test\\resources\\htmlForms\\WorldPay_HTML_Form.html */
	String WORLDPAY_HTML_FORM = System.getProperty("user.dir")+"\\src\\test\\resources\\htmlForms\\WorldPay_HTML_Form.html";
	
}
