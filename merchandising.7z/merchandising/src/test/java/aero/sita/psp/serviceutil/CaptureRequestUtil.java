package aero.sita.psp.serviceutil;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.utility.ReportManager;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.XmlUtil;

public class CaptureRequestUtil extends TestBase {

	private static final Logger LOG = LogManager.getLogger(CaptureRequestUtil.class);
	static Document requestDoc;
	static String xmlRequestPath = "";
	static HttpResponse response;

	
	/**
	 * Method to update Capture Request WorldPay XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createCaptureRequestWorldPay() throws TransformerException {

		reportLog(Status.INFO, LOG, "Updating capture request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("CaptureRequestWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "TransactionID", testData.get("PaymentReference"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "DecimalPlaces", testData.get("DecimalPlaces"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "CurrencyCode", testData.get("CurrencyCode"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "Amount", testData.get("Amount_AP"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("CaptureRequestWorldPay"));
		
	}

	/**
	 * Method to update Capture Request WireCard XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createCaptureRequestWireCard() throws TransformerException {

		reportLog(Status.INFO, LOG, "Updating capture request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("CaptureRequestWireCard"));

		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));
		
		String requestReference = RandomStringUtils.randomAlphanumeric(10).toUpperCase();
		
		if (testData.get("CR_RequestReference").equalsIgnoreCase("Random")) {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "RequestReference", requestReference);
		} else {
			SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "RequestReference", testData.get("CR_RequestReference"));
		}
		SoapUtil.setNodeValue(requestDoc, "psp_common:AccountInfo", "MerchantID", testData.get("MerchantID"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "TransactionID", testData.get("TransactionReference"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "CurrencyCode", testData.get("CurrencyCode"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "Amount", testData.get("Amount_AP"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("CaptureRequestWireCard"));
		
	}
	/**
	 * execute Capture Request.
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeCaptureRequest()
			throws ClientProtocolException, IOException, TransformerException {
		
		reportLog(Status.INFO, LOG, "CaptureRequest Service EndPoint : " + endPoints.get("CaptureRequest"));
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
		xmlRequestPath = createCaptureRequestWorldPay();
		reportLog(Status.INFO, LOG, "Executing capture Request");
		response = SoapUtil.executeSoapRequest(endPoints.get("CaptureRequest"), xmlFiles.get("CaptureRequestWorldPay"),
				xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			xmlRequestPath = createCaptureRequestWireCard();
			reportLog(Status.INFO, LOG, "Executing capture Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("CaptureRequest"), xmlFiles.get("CaptureRequestWireCard"),
					xmlRequestPath);
			}
		return response;
	}
	/**
	 * Method to capture Data from CaptureRequest Response.
	 * @param responseXmlString
	 * @throws DOMException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */
	
	public static void captureRequestResponseData(String responseXmlString) throws DOMException, SAXException, IOException, ParserConfigurationException {
		
		String paymentReference = SoapUtil.getNodeValue(responseXmlString, "MerchantInfo", "PaymentReference");
		String requestReference = "";
		String merchantID = "";
		String transactionReference="";
		
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			requestReference = SoapUtil.getNodeValue(responseXmlString, "MerchantInfo", "RequestReference");
			merchantID = SoapUtil.getNodeValue(responseXmlString, "psp_common:AccountInfo", "MerchantID");
			transactionReference = SoapUtil.getNodeValue(responseXmlString, "IATA_CapturePaymentRS", "TransactionReference");
		}
		testData.put("PaymentReference", paymentReference);
		testData.put("RequestReference", requestReference);
		testData.put("MerchantID", merchantID);
		testData.put("TransactionReference", transactionReference);
		
	}
	
}
