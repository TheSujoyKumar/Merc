package aero.sita.psp.baseutil;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import aero.sita.psp.constants.ProjectConstants;
import aero.sita.psp.utility.ExcelReader;
import aero.sita.psp.utility.ReportManager;

public class TestBase {
	
	
	private static final Logger LOG = LogManager.getLogger(TestBase.class);
	
	
	//public static ExtentReports extent  = ReportManager.getReportInstance("");
	public static ExtentReports extent  = null;
	public static ExtentTest test=null;
	public static Properties env = null;
	public static HashMap<String, String> endPoints;
	public static HashMap<String, String> xmlFiles;
	public static HashMap<String, String> fopDetails;
	public static Map<String, String> testData;
	static{
		DOMConfigurator.configure(System.getProperty("user.dir")+"\\src\\test\\resources\\log4j1.xml");
		env = new Properties();
		FileInputStream fip;
		try {
			fip = new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\environment.properties");
			env.load(fip);
			endPoints = ExcelReader.readGlobalURLs(ProjectConstants.ENDPOINTS_URLS_FILE_PATH, env.getProperty("environment"));
			xmlFiles = ExcelReader.readGlobalURLs(ProjectConstants.requestXmlFilePath, "requestXmlFileList");
			//fopDetails = ExcelReader.readFOPDetails(ProjectConstants.fopDetailsPath, env.getProperty("environment"));
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		}
	
	@BeforeSuite
	public void startup() {
		
	}
	@AfterSuite
	public void tearDown() {
		extent.flush();
	}
	
	/*@AfterTest
	public void flushReport() {
		extent.flush();
	}*/
	
	public void initExtentReport(String testName, String Description) {
		extent  = ReportManager.getReportInstance(testName);
		test = extent.createTest(testName, Description);
	}
	public static void reportLogAsCodeBlock(Status status,Logger LOG,String infoMessage, String responseXml){
		LOG.info(infoMessage+" : "+responseXml);
		test.log(status, infoMessage);
		test.log(status, MarkupHelper.createCodeBlock(responseXml));
	}
	public static void reportLog(Status status,Logger LOG, String messageInfo){
		LOG.info(messageInfo);
		test.log(status, messageInfo);
		
	}
	public static void reportLogAttachScreenshot(String screenshotPath) throws IOException{
		
		test.log(Status.INFO,"", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
		
	}
}
