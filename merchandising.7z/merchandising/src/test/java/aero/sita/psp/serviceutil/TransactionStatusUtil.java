package aero.sita.psp.serviceutil;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.utility.ReportManager;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.XmlUtil;

public class TransactionStatusUtil extends TestBase {
	
	private static final Logger LOG = LogManager.getLogger(TransactionStatusUtil.class);
	static Document requestDoc;
	static String xmlRequestPath = "";
	static HttpResponse response;
	
	
	/**
	 * Method to update Transaction Status check WorldPay Request XML.
	 * 
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createTransactionStatusWorldPayRequest()
			throws TransformerException {
		
		reportLog(Status.INFO, LOG, "Updating Transaction Status check request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("TransactionStatusWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));

		
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("TransactionStatusWorldPay"));
		
		
	}
	
	/**
	 * execute Transaction Status check Request.
	 * 
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeTransactionStatusCheck()
			throws ClientProtocolException, IOException, TransformerException {

		reportLog(Status.INFO, LOG, "Transaction Status check Service EndPoint : " + endPoints.get("TransactionStatusCheck"));
		
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			xmlRequestPath = createTransactionStatusWorldPayRequest();
			reportLog(Status.INFO, LOG, "Executing Transaction Status check Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("TransactionStatusCheck"),
					xmlFiles.get("TransactionStatusWorldPay"), xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			//xmlRequestPath = createAuthorizePaymentWireCardRequest();
			reportLog(Status.INFO, LOG, "Executing Transaction Status check Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("AuthorizePayment"),
					xmlFiles.get("AuthorizePaymentWireCard"), xmlRequestPath);
		}
		return response;
	}
}
