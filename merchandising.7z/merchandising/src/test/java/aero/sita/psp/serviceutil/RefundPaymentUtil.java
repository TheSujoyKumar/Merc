package aero.sita.psp.serviceutil;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.aventstack.extentreports.Status;

import aero.sita.psp.baseutil.TestBase;
import aero.sita.psp.utility.ReportManager;
import aero.sita.psp.utility.SoapUtil;
import aero.sita.psp.utility.XmlUtil;

public class RefundPaymentUtil extends TestBase{
	
	private static final Logger LOG = LogManager.getLogger(RefundPaymentUtil.class);
	static Document requestDoc;
	static String xmlRequestPath = "";
	static HttpResponse response;
	/**
	 * Method to update Refund Payment Request WorldPay XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createRefundPaymentRequestWorldPay() throws TransformerException {

		reportLog(Status.INFO, LOG, "Updating Refund Payment request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("RefundPaymentWorldPay"));

		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "TransactionID", testData.get("PaymentReference"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "CurrencyCode", testData.get("CurrencyCode"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "DecimalPlaces", testData.get("DecimalPlaces"));
		SoapUtil.setNodeValue(requestDoc, "psp_common:PaymentAmount", "Amount", testData.get("RP_Amount"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("RefundPaymentWorldPay"));
	}

	/**
	 * Method to update Refund Payment Request WireCard XML.
	 * 
	 * @param testData
	 * @return
	 * @throws TransformerException
	 * @author SujyontaKumar.Giri
	 */
	public static String createRefundPaymentRequestWireCard() throws TransformerException {

		reportLog(Status.INFO, LOG, "Updating Refund Payment request XML");

		requestDoc = XmlUtil.parseXmlFile(xmlFiles.get("RefundPaymentWireCard"));
		
		String requestReference = RandomStringUtils.randomAlphanumeric(10).toUpperCase();
		
		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "PaymentReference", testData.get("PaymentReference"));
		SoapUtil.setNodeValue(requestDoc, "MerchantInfo", "RequestReference", requestReference);
		SoapUtil.setNodeValue(requestDoc, "psp_common:AccountInfo", "MerchantID", testData.get("MerchantID"));
		
		
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "CurrencyCode", testData.get("CurrencyCode"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "Amount", testData.get("RP_Amount"));
		SoapUtil.setNodeValue(requestDoc, "ReferenceTransaction", "TransactionID", testData.get("TransactionReference"));
		
		return xmlRequestPath = XmlUtil.updateXml(requestDoc,
				ReportManager.outputResponsePath + "\\" + xmlFiles.get("RefundPaymentWireCard"));
	}
	/**
	 * execute Refund Payment Request.
	 * @param testData
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws TransformerException
	 */
	public static HttpResponse executeRefundPayment()
			throws ClientProtocolException, IOException, TransformerException {
		
		reportLog(Status.INFO, LOG, "Refund Payment Service EndPoint : " + endPoints.get("RefundPayment"));
		if (testData.get("Host").equalsIgnoreCase("WORLDPAY")) {
			xmlRequestPath = createRefundPaymentRequestWorldPay();
			reportLog(Status.INFO, LOG, "Executing Refund Payment Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("RefundPayment"),
					xmlFiles.get("RefundPaymentWorldPay"), xmlRequestPath);
		}
		if (testData.get("Host").equalsIgnoreCase("WIRECARD")) {
			xmlRequestPath = createRefundPaymentRequestWireCard();
			reportLog(Status.INFO, LOG, "Executing Refund Payment Request");
			response = SoapUtil.executeSoapRequest(endPoints.get("RefundPayment"),
					xmlFiles.get("RefundPaymentWireCard"), xmlRequestPath);
		}
		return response;
	}
}
