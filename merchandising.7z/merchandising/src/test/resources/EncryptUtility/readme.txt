1. Please make sure that Java 1.5 or above version is installed in the computer
2. In the environment variable for Path, it should contain the directory where java.exe is present
   For example if java is installed in D:\software\jdk160_05, then java.ex will be present in D:\software\jdk160_05\bin.
   This directory (D:\software\jdk160_05\bin) should be added to the "Path" environment variable. You can access it from
    Desktop-->My Computer-->Advanced Tab -->Environment Variables-->System Variables-->Click on Path and add the above entry in the end
3. After step 2 open a command prompt and type java -version. It should print the version of the JVM
4. Save all the files to a local directory say D:\EncryptUtility. Make sure the path to the directory and the directory name has no spaces.
5. In RunEncryption.bat edit the values for 
      a)ENCRYPTION_DIR - Specify the directory where the files are placed. i.e, D:\EncryptUtility for this example.
      b)KEY_MODULUS - Specify the public key modulus as received from the GetKey operation of the KeyDispenser service. Remove the spaces if present.
	  c)KEY_PUBLIC_EXPONENT - Specify the public key exponent as received from the GetKey operation of the KeyDispenser service.
6. Enter the plain text data in the input.txt file. Each data which is to be encrypted need to be specified in a new line.
7. The output will be printed into output.txt the same folder. The text appearing between <!--Start of Encrypted Data for "$Input_data_specified" --> and <!--End of Encrypted Data--> is the encrypted data.
8. If required to enter the KEY_MODULUS and KEY_PUBLIC_EXPONENT as command line parameters to the RunEncryption.bat, edit the bath file and replace "%KEY_MODULUS% %KEY_PUBLIC_EXPONENT%" with "%1 %2"

